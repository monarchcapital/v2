# pages/Fundamentals.py
import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime

st.set_page_config(page_title="Monarch: Investment Analysis", layout="wide")

st.header("📊 Investment Analysis & Portfolio Management")
st.markdown("""
This advanced dashboard provides a holistic view of a company's investment potential, combining multiple valuation models, financial health diagnostics, and peer analysis to support sophisticated investment decisions.
""")

# --- Stock Ticker Input ---
ticker_input = st.text_area(
    "Enter Stock Ticker Symbol(s) (e.g., RELIANCE.NS, AAPL, MSFT - separate by comma or new line):",
    "MSFT, AAPL"
)
tickers = [t.strip().upper() for t in ticker_input.replace('\n', ',').split(',') if t.strip()]

# --- Sidebar for Advanced Configuration ---
with st.sidebar:
    st.header("📈 Valuation & Portfolio Config")
    st.subheader("Margin of Safety (MoS)")
    margin_of_safety = st.slider("Required Margin of Safety (%)", 0, 50, 20, key='main_mos')

    st.subheader("Valuation Model Weighting")
    st.info("Assign weights to each model to calculate a blended fair value.")
    weight_dcf = st.slider("DCF Weight", 0, 100, 40, key='w_dcf')
    weight_ddm = st.slider("DDM Weight", 0, 100, 20, key='w_ddm')
    weight_graham = st.slider("Graham Weight", 0, 100, 20, key='w_graham')
    weight_ev = st.slider("EV Multiples Weight", 0, 100, 20, key='w_ev')
    
    total_weight = weight_dcf + weight_ddm + weight_graham + weight_ev
    if total_weight != 100:
        st.warning(f"Weights must sum to 100. Current sum: {total_weight}")

    with st.expander("DCF Model Parameters"):
        growth_rate = st.slider("FCF Growth Rate (%)", 5, 30, 10, key='g_rate') / 100
        terminal_growth = st.slider("Terminal Growth Rate (%)", 1, 10, 3, key='t_growth') / 100
        discount_rate = st.slider("Discount Rate (WACC) (%)", 5, 20, 9, key='d_rate') / 100

# --- Data Fetching and Caching ---
@st.cache_data(ttl=3600)
def fetch_data_bundle(ticker_symbol):
    try:
        stock = yf.Ticker(ticker_symbol)
        info = stock.info
        if not info or info.get('quoteType') != 'EQUITY': return {}
        
        return {
            "info": info, "financials": stock.financials, "balance_sheet": stock.balance_sheet,
            "cash_flow": stock.cashflow, "history": stock.history(period="5y")
        }
    except Exception: return {}

# --- Advanced Calculation Functions ---
def calculate_dcf(info, cash_flow, g, t_g, wacc):
    try:
        fcf = cash_flow.loc['Total Cash From Operating Activities'].iloc[0] + cash_flow.loc['Capital Expenditure'].iloc[0]
        shares, cash, debt = info.get('sharesOutstanding'), info.get('totalCash'), info.get('totalDebt')
        if not all([fcf, shares, cash, debt]): return None
        
        future_fcf = [fcf * ((1 + g) ** y) for y in range(1, 6)]
        terminal_value = future_fcf[-1] * (1 + t_g) / (wacc - t_g)
        discounted_fcf = [cf / ((1 + wacc) ** (i+1)) for i, cf in enumerate(future_fcf)]
        enterprise_value = sum(discounted_fcf) + (terminal_value / ((1 + wacc) ** 5))
        equity_value = enterprise_value - debt + cash
        return equity_value / shares
    except (KeyError, TypeError, ZeroDivisionError): return None

def calculate_ddm(info, wacc, t_g):
    try:
        dps = info.get('dividendRate')
        if not dps: return None
        return dps * (1 + t_g) / (wacc - t_g)
    except (TypeError, ZeroDivisionError): return None

def calculate_graham_number(info):
    try:
        eps, bvps = info.get('trailingEps'), info.get('bookValue')
        if not eps or not bvps or eps <= 0: return None
        return np.sqrt(22.5 * eps * bvps)
    except (TypeError, ValueError): return None

def calculate_ev_multiple_value(info, balance_sheet):
    try:
        ev = info.get('enterpriseValue')
        ebitda = info.get('ebitda')
        shares = info.get('sharesOutstanding')
        industry = info.get('industry')
        # Simplified industry EV/EBITDA multiples
        industry_multiples = {'Software—Infrastructure': 25, 'Semiconductors': 20, 'Banks—Regional': 10, 'Oil & Gas E&P': 6}
        multiple = industry_multiples.get(industry, 15) # Default multiple
        fair_value = (ebitda * multiple) / shares
        return fair_value
    except (TypeError, ZeroDivisionError): return None

def calculate_piotroski_f_score(financials, balance_sheet, cash_flow):
    try:
        score = 0
        # Profitability
        ni = financials.loc['Net Income'].iloc[0]
        score += 1 if ni > 0 else 0
        cfo = cash_flow.loc['Total Cash From Operating Activities'].iloc[0]
        score += 1 if cfo > 0 else 0
        assets_y1 = balance_sheet.loc['Total Assets'].iloc[1]
        roa_y0 = ni / assets_y1
        ni_y1 = financials.loc['Net Income'].iloc[1]
        assets_y2 = balance_sheet.loc['Total Assets'].iloc[2]
        roa_y1 = ni_y1 / assets_y2
        score += 1 if roa_y0 > roa_y1 else 0
        score += 1 if cfo > ni else 0
        # Leverage, Liquidity, Source of Funds
        debt_y0 = balance_sheet.loc['Total Liab'].iloc[0]
        debt_y1 = balance_sheet.loc['Total Liab'].iloc[1]
        score += 1 if (debt_y0 / assets_y1) < (debt_y1 / assets_y2) else 0
        # ... (add more Piotroski criteria)
        return score
    except (KeyError, IndexError): return "N/A"

# --- Main Application Logic ---
if not tickers:
    st.info("ℹ️ Please enter one or more stock ticker symbols to begin the analysis.")
else:
    for ticker in tickers:
        st.markdown(f"---")
        data = fetch_data_bundle(ticker)
        if not data:
            st.error(f"Could not process {ticker}. Please check the symbol and try again.")
            continue

        info = data["info"]
        st.header(f"{info.get('longName', ticker)} ({ticker})")
        
        # --- Calculations ---
        dcf_val = calculate_dcf(info, data['cash_flow'], growth_rate, terminal_growth, discount_rate)
        ddm_val = calculate_ddm(info, discount_rate, terminal_growth)
        graham_val = calculate_graham_number(info)
        ev_val = calculate_ev_multiple_value(info, data['balance_sheet'])
        
        valuations = {'DCF': dcf_val, 'DDM': ddm_val, 'Graham': graham_val, 'EV Multiple': ev_val}
        weights = {'DCF': weight_dcf, 'DDM': weight_ddm, 'Graham': weight_graham, 'EV Multiple': weight_ev}
        
        valid_vals = [valuations[k] for k, w in weights.items() if valuations[k] is not None and w > 0]
        valid_weights = [w for k, w in weights.items() if valuations[k] is not None and w > 0]
        
        weighted_avg = np.average(valid_vals, weights=valid_weights) if valid_vals else None
        buy_price = weighted_avg * (1 - margin_of_safety/100) if weighted_avg else None
        current_price = info.get('currentPrice')

        # --- Tabs ---
        summary_tab, valuation_tab, health_tab, peers_tab, risk_tab = st.tabs(["Summary & Verdict", "Valuation Models", "Financial Health", "Peer Comparison", "Risk Analysis"])

        with summary_tab:
            verdict = "N/A"
            if buy_price and current_price:
                if current_price < buy_price: verdict = "Potentially Undervalued"
                elif current_price > weighted_avg: verdict = "Potentially Overvalued"
                else: verdict = "Fairly Valued"
            
            st.metric("Investment Verdict", verdict)
            col1, col2, col3 = st.columns(3)
            col1.metric("Current Price", f"${current_price:,.2f}")
            col2.metric("Weighted Fair Value", f"${weighted_avg:,.2f}" if weighted_avg else "N/A")
            col3.metric(f"Target Buy Price ({margin_of_safety}% MoS)", f"${buy_price:,.2f}" if buy_price else "N/A")

        with valuation_tab:
            st.subheader("Intrinsic Value Breakdown")
            # Display each model's result here...

        with health_tab:
            st.subheader("Financial Health & Quality Score")
            piotroski_score = calculate_piotroski_f_score(data['financials'], data['balance_sheet'], data['cash_flow'])
            st.metric("Piotroski F-Score (0-9)", f"{piotroski_score}/9")
            # Add DuPont and Altman Z-Score displays...
        
        with peers_tab:
            st.subheader("Peer & Industry Comparison")
            st.info("Peer comparison functionality would be implemented here.")

        with risk_tab:
            st.subheader("Risk Analysis")
            beta = info.get('beta')
            st.metric("Beta (Market Risk)", f"{beta:.2f}" if beta else "N/A")
            # Add Volatility and Sortino Ratio...
