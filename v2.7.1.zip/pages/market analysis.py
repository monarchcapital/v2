# pages/Market_Analysis.py
import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
from datetime import timedelta, date, datetime
import time
from functools import reduce

import config
from utils import (
    download_data, create_features, train_models_pipeline,
    generate_iterative_forecast, parse_int_list,
    add_market_data_features, add_fundamental_features
)

st.set_page_config(page_title="Monarch: Market Analysis", layout="wide")

st.header("📈 Market Analysis Dashboard")
st.markdown("Get a high-level view of the market by analyzing global indices, specific markets like the NIFTY 50, and sector-level performance.")

# --- Helper Functions for Advanced Analysis ---
def get_feature_importance_explanation(df_importance, ticker):
    if df_importance.empty: return "Feature importance data is not available for this model."
    top_feature = df_importance.iloc[0]['Feature']
    explanation = f"The forecast is most heavily influenced by **'{top_feature.replace('_', ' ')}'**. "
    if 'Lag' in top_feature: explanation += "This indicates strong reliance on recent price momentum."
    elif 'MA_' in top_feature: explanation += "This suggests the model is prioritizing the current trend."
    elif 'RSI' in top_feature: explanation += "This means the model sees the index's overbought/oversold status as the key driver."
    else: explanation += "This technical indicator is playing a crucial role."
    return explanation

def calculate_support_resistance(df):
    if len(df) < 30: return np.nan, np.nan
    support = df['Low'].rolling(window=30, center=True).min().dropna().iloc[-1]
    resistance = df['High'].rolling(window=30, center=True).max().dropna().iloc[-1]
    return support, resistance

def get_technical_outlook(df):
    outlook = "Neutral"
    score = 0
    last_close = df['Close'].iloc[-1]
    temp_params = {'MA_WINDOWS': [50, 200], 'RSI_WINDOW': 14, 'MACD_SHORT_WINDOW': 12, 'MACD_LONG_WINDOW': 26, 'MACD_SIGNAL_WINDOW': 9}
    df_with_indicators = create_features(df.copy(), temp_params)
    
    if 'MA_50' in df_with_indicators and not df_with_indicators['MA_50'].empty and last_close > df_with_indicators['MA_50'].iloc[-1]: score += 1
    else: score -=1
    if 'MA_200' in df_with_indicators and not df_with_indicators['MA_200'].empty and last_close > df_with_indicators['MA_200'].iloc[-1]: score += 1
    else: score -= 1
    if 'RSI' in df_with_indicators and not df_with_indicators['RSI'].empty and df_with_indicators['RSI'].iloc[-1] > 50: score += 1
    if 'MACD' in df_with_indicators and not df_with_indicators['MACD'].empty and df_with_indicators['MACD'].iloc[-1] > df_with_indicators['MACD_Signal'].iloc[-1]: score += 1
    
    if score >= 3: outlook = "Bullish"
    elif score <= -1: outlook = "Bearish"
    return outlook

# --- NIFTY 50 Constituent Data ---
FALLBACK_NIFTY50_STOCKS = {
    'HDFCBANK.NS': 11.59, 'RELIANCE.NS': 9.69, 'ICICIBANK.NS': 7.87, 'INFY.NS': 5.02, 'LT.NS': 4.50, 'TCS.NS': 4.00, 'BHARTIARTL.NS': 3.70, 'ITC.NS': 3.50, 'KOTAKBANK.NS': 3.00, 'HINDUNILVR.NS': 2.53, 'AXISBANK.NS': 2.40, 'BAJFINANCE.NS': 2.20, 'MARUTI.NS': 2.16, 'M&M.NS': 2.10, 'SBIN.NS': 1.98, 'SUNPHARMA.NS': 1.88, 'TATAMOTORS.NS': 1.85, 'NTPC.NS': 1.62, 'POWERGRID.NS': 1.50, 'TATASTEEL.NS': 1.35, 'ADANIENT.NS': 1.29, 'ULTRACEMCO.NS': 1.25, 'ASIANPAINT.NS': 1.19, 'COALINDIA.NS': 1.17, 'BAJAJFINSV.NS': 1.13, 'HCLTECH.NS': 1.11, 'NESTLEIND.NS': 0.95, 'JSWSTEEL.NS': 0.94, 'INDUSINDBK.NS': 0.92, 'ADANIPORTS.NS': 0.89, 'GRASIM.NS': 0.81, 'HINDALCO.NS': 0.79, 'EICHERMOT.NS': 0.75, 'DRREDDY.NS': 0.73, 'SBILIFE.NS': 0.71, 'TITAN.NS': 0.69, 'CIPLA.NS': 0.68, 'TECHM.NS': 0.65, 'BAJAJ-AUTO.NS': 0.61, 'WIPRO.NS': 0.59, 'SHREECEM.NS': 0.57, 'HEROMOTOCO.NS': 0.55, 'DIVISLAB.NS': 0.53, 'APOLLOHOSP.NS': 0.51, 'LTIM.NS': 0.49, 'BRITANNIA.NS': 0.47, 'ONGC.NS': 0.45, 'BPCL.NS': 0.43, 'HDFCLIFE.NS': 0.41, 'SHRIRAMFIN.NS': 0.38
}

@st.cache_data(ttl=86400)
def get_nifty50_constituents():
    try:
        etf_ticker = yf.Ticker("NIFTYBEES.NS")
        holdings = etf_ticker.info.get('holdings')
        if not holdings: raise ValueError("Could not retrieve holdings.")
        weights_dict = {(stock.get('symbol') + ('' if stock.get('symbol', '').endswith(('.NS', '.BO')) else '.NS')): stock.get('holdingPercent') * 100 for stock in holdings if stock.get('symbol') and stock.get('holdingPercent')}
        return weights_dict if len(weights_dict) > 45 else FALLBACK_NIFTY50_STOCKS
    except Exception: return FALLBACK_NIFTY50_STOCKS

# --- Tabbed Interface ---
tab1, tab2, tab3 = st.tabs(["🌍 Global Index Analysis", "🇮🇳 NIFTY 50 Forecast", "🏢 NIFTY Sector Analysis"])

# --- Tab 1: Global Index Analysis ---
with tab1:
    st.subheader("Global Index Analysis & Forecast")
    
    with st.sidebar:
        st.header("🛠️ Global Index Config")
        selected_index_name = st.selectbox("Select Primary Index:", options=list(config.GLOBAL_MARKET_TICKERS.keys()), key="global_index_select")
        ticker_global = config.GLOBAL_MARKET_TICKERS[selected_index_name]
        
        today_global = date.today()
        end_date_global = st.date_input("End Date:", value=today_global - timedelta(days=1), key="global_end")
        start_date_global = st.date_input("Start Date:", value=end_date_global - timedelta(days=5*365), key="global_start")
        n_future_global = st.slider("Predict Future Days:", 1, 90, 15, key="global_future")
        
        model_to_display_global = st.selectbox("Select Model to Analyze:", options=[m for m in config.MODEL_CHOICES if m != 'Prophet'], key="global_model")

    if st.button(f"Run Analysis for {selected_index_name}", key="run_global"):
        indicator_params_global = {k: v[0] for k, v in config.TECHNICAL_INDICATORS_DEFAULTS.items()}

        with st.spinner(f"Fetching and processing data for {selected_index_name}..."):
            data_global = download_data(ticker_global)
            if data_global.empty: st.error(f"Could not download data for {ticker_global}."); st.stop()
            
            df_features_global = create_features(data_global.copy(), indicator_params_global)
            df_train_global = df_features_global[(df_features_global['Date'] >= pd.to_datetime(start_date_global)) & (df_features_global['Date'] <= pd.to_datetime(end_date_global))]

        with st.spinner(f"Training {model_to_display_global} model..."):
            trained_models_global, _ = train_models_pipeline(df_train_global.copy(), model_to_display_global, False, (lambda x: None), indicator_params_global)
            future_df_global = generate_iterative_forecast(data_global, trained_models_global, ticker_global, n_future_global, end_date_global, indicator_params_global, (lambda x: None))

        st.success("Analysis Complete!")
        
        support, resistance = calculate_support_resistance(df_features_global.tail(60))
        outlook = get_technical_outlook(data_global.tail(250))
        
        col1, col2, col3 = st.columns(3)
        col1.metric("Technical Outlook", outlook)
        col2.metric("Key Support", f"{support:,.2f}")
        col3.metric("Key Resistance", f"{resistance:,.2f}")

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=data_global['Date'], y=data_global['Close'], mode='lines', name=f'Historical {selected_index_name}'))
        fig.add_trace(go.Scatter(x=future_df_global['Date'], y=future_df_global['Close'], mode='lines', name=f'Forecasted {selected_index_name}', line=dict(dash='dot', color='red')))
        fig.add_hline(y=support, line_dash="dash", line_color="green", annotation_text="Support")
        fig.add_hline(y=resistance, line_dash="dash", line_color="red", annotation_text="Resistance")
        st.plotly_chart(fig, use_container_width=True)

        st.subheader("Prediction Rationale")
        model_info = trained_models_global.get('Close')
        if model_info and hasattr(model_info['model'], 'feature_importances_'):
            imp_df = pd.DataFrame({'Feature': model_info['features'], 'Importance': model_info['model'].feature_importances_}).sort_values(by='Importance', ascending=False).head(10)
            st.markdown(get_feature_importance_explanation(imp_df, selected_index_name))
            st.dataframe(imp_df)
        else:
            st.info(f"Feature importance not available for {model_to_display_global}.")

# --- Tab 2: NIFTY 50 Forecast ---
with tab2:
    st.subheader("NIFTY 50 Forecast Comparison")
    
    with st.sidebar:
        st.header("🛠️ NIFTY Forecast Config")
        nifty_model_direct = st.selectbox("Select Model (Direct):", options=[m for m in config.MODEL_CHOICES if m != 'Prophet'], key="nifty_direct_model")
        nifty_model_component = st.selectbox("Select Model (Component):", options=[m for m in config.MODEL_CHOICES if m != 'Prophet'], key="nifty_component_model")
        n_future_nifty = st.slider("Predict Future Days:", 1, 90, 15, key="nifty_future_days")

    if st.button("Run NIFTY 50 Forecast", key="run_nifty_forecast"):
        st.info("This is a computationally intensive process. Please be patient.")
        # (Full logic will be implemented here)

# --- Tab 3: NIFTY Sector Analysis ---
with tab3:
    st.subheader("NIFTY 50 Sector-wise Analysis & Signals")
    
    with st.sidebar:
        st.header("⚙️ Trading Signal Config")
        min_roe = st.slider("Min. ROE (%)", 0, 30, 15, key="nifty_roe")
        max_pe = st.slider("Max. P/E Ratio", 10.0, 50.0, 25.0, step=1.0, key="nifty_pe")
        ma_window = st.slider("MA Window (days)", 5, 50, 20, key="nifty_ma")

    if st.button("Analyze NIFTY 50 Sectors", key="run_sector_analysis"):
        st.info("Fetching data for all 50 constituents. This may take a few minutes...")
        # (Full logic will be implemented here)
